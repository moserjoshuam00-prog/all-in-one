import { useReducer, useEffect } from 'react';
import { BudgetState, BudgetAction, Expense, SavingsGoal } from '../types';
import { DEFAULT_CATEGORIES } from '../utils/categories';

const STORAGE_KEY = 'budget-planner-data';

const initialState: BudgetState = {
  income: 0,
  expenses: [],
  categories: [...DEFAULT_CATEGORIES],
  isDarkMode: false,
  savingsGoal: null,
};

const budgetReducer = (state: BudgetState, action: BudgetAction): BudgetState => {
  switch (action.type) {
    case 'SET_INCOME':
      return { ...state, income: action.payload };
    
    case 'ADD_EXPENSE':
      return {
        ...state,
        expenses: [...state.expenses, action.payload],
      };
    
    case 'UPDATE_EXPENSE':
      return {
        ...state,
        expenses: state.expenses.map((exp) =>
          exp.id === action.payload.id
            ? { ...exp, ...action.payload.expense }
            : exp
        ),
      };
    
    case 'DELETE_EXPENSE':
      return {
        ...state,
        expenses: state.expenses.filter((exp) => exp.id !== action.payload),
      };
    
    case 'ADD_CATEGORY':
      if (!state.categories.includes(action.payload)) {
        return {
          ...state,
          categories: [...state.categories, action.payload],
        };
      }
      return state;
    
    case 'TOGGLE_DARK_MODE':
      return { ...state, isDarkMode: !state.isDarkMode };
    
    case 'SET_SAVINGS_GOAL':
      return { ...state, savingsGoal: action.payload };
    
    case 'UPDATE_SAVINGS_AMOUNT':
      if (state.savingsGoal) {
        return {
          ...state,
          savingsGoal: {
            ...state.savingsGoal,
            currentAmount: action.payload,
          },
        };
      }
      return state;
    
    case 'LOAD_STATE':
      return action.payload;
    
    default:
      return state;
  }
};

export const useBudget = () => {
  const [state, dispatch] = useReducer(budgetReducer, initialState);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        dispatch({ type: 'LOAD_STATE', payload: parsed });
      } catch (e) {
        console.error('Failed to load saved data:', e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const totalExpenses = state.expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const remaining = state.income - totalExpenses;
  const isPositive = remaining >= 0;

  const getCategoryTotal = (category: string) => {
    return state.expenses
      .filter((exp) => exp.category === category)
      .reduce((sum, exp) => sum + exp.amount, 0);
  };

  const addExpense = (expense: Omit<Expense, 'id' | 'date'>) => {
    const newExpense: Expense = {
      ...expense,
      id: Date.now().toString(),
      date: new Date().toISOString(),
    };
    dispatch({ type: 'ADD_EXPENSE', payload: newExpense });
  };

  const updateExpense = (id: string, expense: Omit<Expense, 'id'>) => {
    dispatch({ type: 'UPDATE_EXPENSE', payload: { id, expense } });
  };

  const deleteExpense = (id: string) => {
    dispatch({ type: 'DELETE_EXPENSE', payload: id });
  };

  const addCategory = (category: string) => {
    dispatch({ type: 'ADD_CATEGORY', payload: category });
  };

  const setSavingsGoal = (goal: SavingsGoal | null) => {
    dispatch({ type: 'SET_SAVINGS_GOAL', payload: goal });
  };

  const updateSavingsAmount = (amount: number) => {
    dispatch({ type: 'UPDATE_SAVINGS_AMOUNT', payload: amount });
  };

  return {
    state,
    totalExpenses,
    remaining,
    isPositive,
    getCategoryTotal,
    addExpense,
    updateExpense,
    deleteExpense,
    addCategory,
    setIncome: (income: number) => dispatch({ type: 'SET_INCOME', payload: income }),
    toggleDarkMode: () => dispatch({ type: 'TOGGLE_DARK_MODE' }),
    setSavingsGoal,
    updateSavingsAmount,
  };
};