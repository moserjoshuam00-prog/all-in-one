import { useReducer, useEffect } from 'react';
import { Habit } from '../types';

interface HabitsState {
  habits: Habit[];
}

type HabitAction =
  | { type: 'SET_HABITS'; payload: Habit[] }
  | { type: 'ADD_HABIT'; payload: Habit }
  | { type: 'DELETE_HABIT'; payload: string }
  | { type: 'TOGGLE_DAY'; payload: { id: string; date: string } };

const habitsReducer = (state: HabitsState, action: HabitAction): HabitsState => {
  switch (action.type) {
    case 'SET_HABITS':
      return { habits: action.payload };
    case 'ADD_HABIT':
      return { habits: [...state.habits, action.payload] };
    case 'DELETE_HABIT':
      return { habits: state.habits.filter((h) => h.id !== action.payload) };
    case 'TOGGLE_DAY':
      return {
        habits: state.habits.map((habit) => {
          if (habit.id !== action.payload.id) return habit;
          
          const dateIndex = habit.completedDates.indexOf(action.payload.date);
          let newDates;
          
          if (dateIndex > -1) {
            newDates = habit.completedDates.filter((d) => d !== action.payload.date);
          } else {
            newDates = [...habit.completedDates, action.payload.date];
          }

          return { ...habit, completedDates: newDates };
        }),
      };
    default:
      return state;
  }
};

export const useHabits = () => {
  const [state, dispatch] = useReducer(habitsReducer, { habits: [] });

  useEffect(() => {
    const saved = localStorage.getItem('habits');
    if (saved) {
      try {
        dispatch({ type: 'SET_HABITS', payload: JSON.parse(saved) });
      } catch (e) {
        console.error('Fehler beim Laden der Gewohnheiten', e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('habits', JSON.stringify(state.habits));
  }, [state.habits]);

  const addHabit = (habitData: Omit<Habit, 'id' | 'createdAt' | 'completedDates'>) => {
    const newHabit: Habit = {
      ...habitData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      completedDates: [],
    };
    dispatch({ type: 'ADD_HABIT', payload: newHabit });
  };

  const deleteHabit = (id: string) => {
    dispatch({ type: 'DELETE_HABIT', payload: id });
  };

  const toggleHabitDay = (id: string, date: string) => {
    dispatch({ type: 'TOGGLE_DAY', payload: { id, date } });
  };

  const getStreak = (habit: Habit): number => {
    const sortedDates = [...habit.completedDates].sort().reverse();
    if (sortedDates.length === 0) return 0;

    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Check if completed today or yesterday to keep streak alive
    const lastCompleted = new Date(sortedDates[0]);
    lastCompleted.setHours(0, 0, 0, 0);
    
    const diffTime = Math.abs(today.getTime() - lastCompleted.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays > 1) return 0; // Streak broken

    for (let i = 0; i < sortedDates.length; i++) {
      const d = new Date(sortedDates[i]);
      d.setHours(0, 0, 0, 0);
      
      const expectedDate = new Date(today);
      expectedDate.setDate(today.getDate() - i);
      expectedDate.setHours(0, 0, 0, 0);

      if (d.getTime() === expectedDate.getTime()) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  };

  const habits = state.habits;
  const activeHabits = habits.length;
  const maxStreak = habits.length > 0 ? Math.max(...habits.map(getStreak)) : 0;
  
  const todayString = new Date().toISOString().split('T')[0];
  const todayProgress = habits.length > 0
    ? habits.filter(h => h.completedDates.includes(todayString)).length
    : 0;

  return {
    habits,
    activeHabits,
    maxStreak,
    todayProgress,
    getStreak,
    addHabit,
    deleteHabit,
    toggleHabitDay,
  };
};