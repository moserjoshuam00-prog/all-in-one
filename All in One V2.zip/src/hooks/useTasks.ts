import { useReducer, useEffect } from 'react';
import { Task } from '../types';

interface TasksState {
  tasks: Task[];
}

type TaskAction =
  | { type: 'SET_TASKS'; payload: Task[] }
  | { type: 'ADD_TASK'; payload: Task }
  | { type: 'UPDATE_TASK'; payload: { id: string; updates: Partial<Task> } }
  | { type: 'DELETE_TASK'; payload: string }
  | { type: 'TOGGLE_TASK'; payload: string };

const tasksReducer = (state: TasksState, action: TaskAction): TasksState => {
  switch (action.type) {
    case 'SET_TASKS':
      return { tasks: action.payload };
    case 'ADD_TASK':
      return { tasks: [...state.tasks, action.payload] };
    case 'UPDATE_TASK':
      return {
        tasks: state.tasks.map((task) =>
          task.id === action.payload.id ? { ...task, ...action.payload.updates } : task
        ),
      };
    case 'DELETE_TASK':
      return { tasks: state.tasks.filter((task) => task.id !== action.payload) };
    case 'TOGGLE_TASK':
      return {
        tasks: state.tasks.map((task) =>
          task.id === action.payload ? { ...task, completed: !task.completed } : task
        ),
      };
    default:
      return state;
  }
};

export const useTasks = () => {
  const [state, dispatch] = useReducer(tasksReducer, { tasks: [] });

  useEffect(() => {
    const saved = localStorage.getItem('tasks');
    if (saved) {
      try {
        dispatch({ type: 'SET_TASKS', payload: JSON.parse(saved) });
      } catch (e) {
        console.error('Fehler beim Laden der Aufgaben', e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(state.tasks));
  }, [state.tasks]);

  const addTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    dispatch({ type: 'ADD_TASK', payload: newTask });
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    dispatch({ type: 'UPDATE_TASK', payload: { id, updates } });
  };

  const deleteTask = (id: string) => {
    dispatch({ type: 'DELETE_TASK', payload: id });
  };

  const toggleTask = (id: string) => {
    dispatch({ type: 'TOGGLE_TASK', payload: id });
  };

  const tasks = state.tasks.sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });

  const pendingTasks = tasks.filter((t) => !t.completed);
  const completedTasks = tasks.filter((t) => t.completed);
  const nextTasks = pendingTasks.slice(0, 3);

  return {
    tasks,
    pendingTasks,
    completedTasks,
    nextTasks,
    addTask,
    updateTask,
    deleteTask,
    toggleTask,
  };
};