import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Expense } from '../types';

interface ExpenseFormProps {
  categories: string[];
  onAddExpense: (expense: Omit<Expense, 'id' | 'date'>) => void;
  onAddCategory: (category: string) => void;
  editingExpense?: Expense | null;
  onCancelEdit?: () => void;
}

export const ExpenseForm = ({
  categories,
  onAddExpense,
  onAddCategory,
  editingExpense,
  onCancelEdit,
}: ExpenseFormProps) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [newCategory, setNewCategory] = useState('');
  const [showNewCategoryInput, setShowNewCategoryInput] = useState(false);

  useEffect(() => {
    if (editingExpense) {
      setName(editingExpense.name);
      setAmount(editingExpense.amount.toString());
      setCategory(editingExpense.category);
    } else {
      setName('');
      setAmount('');
      setCategory('');
    }
  }, [editingExpense]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !amount || !category) return;

    onAddExpense({
      name: name.trim(),
      amount: parseFloat(amount),
      category,
    });

    if (!editingExpense) {
      setName('');
      setAmount('');
      setCategory('');
    }
  };

  const handleAddCategory = () => {
    if (newCategory.trim()) {
      onAddCategory(newCategory.trim());
      setCategory(newCategory.trim());
      setNewCategory('');
      setShowNewCategoryInput(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="expense-name">Bezeichnung</Label>
        <Input
          id="expense-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="z.B. Lebensmittel"
        />
      </div>

      <div>
        <Label htmlFor="expense-amount">Betrag (€)</Label>
        <Input
          id="expense-amount"
          type="number"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="0.00"
        />
      </div>

      <div>
        <Label htmlFor="expense-category">Kategorie</Label>
        {!showNewCategoryInput ? (
          <div className="flex gap-2">
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger id="expense-category" className="flex-1">
                <SelectValue placeholder="Kategorie wählen" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => setShowNewCategoryInput(true)}
              title="Neue Kategorie"
            >
              +
            </Button>
          </div>
        ) : (
          <div className="flex gap-2">
            <Input
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              placeholder="Neue Kategorie"
            />
            <Button type="button" onClick={handleAddCategory}>
              Hinzufügen
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowNewCategoryInput(false)}
            >
              X
            </Button>
          </div>
        )}
      </div>

      <div className="flex gap-2">
        <Button type="submit" className="flex-1 bg-red-600 hover:bg-red-700">
          {editingExpense ? 'Aktualisieren' : 'Ausgabe hinzufügen'}
        </Button>
        {editingExpense && onCancelEdit && (
          <Button type="button" variant="outline" onClick={onCancelEdit}>
            Abbrechen
          </Button>
        )}
      </div>
    </form>
  );
};