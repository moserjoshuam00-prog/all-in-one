import { Sun, Moon } from 'lucide-react';
import { Button } from './ui/button';

interface BudgetHeaderProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const BudgetHeader = ({ isDarkMode, onToggleDarkMode }: BudgetHeaderProps) => {
  return (
    <header className="flex justify-between items-center mb-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">
          Life Manager
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Dein persönlicher Dashboard
        </p>
      </div>

      <Button
        onClick={onToggleDarkMode}
        variant="outline"
        size="icon"
        className="rounded-full border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
        aria-label={isDarkMode ? 'Zu hellem Modus wechseln' : 'Zu dunklem Modus wechseln'}
      >
        {isDarkMode ? (
          <Sun className="h-5 w-5 text-yellow-500 transition-transform hover:rotate-90" />
        ) : (
          <Moon className="h-5 w-5 text-blue-600 transition-transform hover:-rotate-12" />
        )}
      </Button>
    </header>
  );
};