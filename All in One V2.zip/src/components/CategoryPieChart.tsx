import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { PieChart } from 'lucide-react';
import { getCategoryColor } from '../utils/categories';

interface CategoryPieChartProps {
  getCategoryTotal: (category: string) => number;
  categories: string[];
  totalExpenses: number;
}

export const CategoryPieChart = ({
  getCategoryTotal,
  categories,
  totalExpenses,
}: CategoryPieChartProps) => {
  if (totalExpenses === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="h-5 w-5" />
            Ausgaben nach Kategorien
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 text-gray-500">
            <p>Noch keine Ausgaben erfasst</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const categoryData = categories
    .map((category) => ({
      category,
      total: getCategoryTotal(category),
    }))
    .filter((data) => data.total > 0)
    .sort((a, b) => b.total - a.total);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR',
    }).format(value);
  };

  // Calculate SVG pie chart
  let cumulativePercent = 0;
  const slices = categoryData.map((data) => {
    const percent = data.total / totalExpenses;
    const startPercent = cumulativePercent;
    const endPercent = cumulativePercent + percent;
    cumulativePercent = endPercent;

    const startX = Math.cos(2 * Math.PI * startPercent - Math.PI / 2) * 50 + 50;
    const startY = Math.sin(2 * Math.PI * startPercent - Math.PI / 2) * 50 + 50;
    const endX = Math.cos(2 * Math.PI * endPercent - Math.PI / 2) * 50 + 50;
    const endY = Math.sin(2 * Math.PI * endPercent - Math.PI / 2) * 50 + 50;

    const largeArcFlag = percent > 0.5 ? 1 : 0;

    return {
      ...data,
      percent,
      path: `M 50 50 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z`,
    };
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PieChart className="h-5 w-5" />
          Ausgaben nach Kategorien
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="relative w-64 h-64">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {slices.map((slice, index) => (
                <path
                  key={slice.category}
                  d={slice.path}
                  fill="currentColor"
                  className={getCategoryColor(slice.category).replace('bg-', 'text-')}
                  opacity="0.9"
                >
                  <title>
                    {slice.category}: {formatCurrency(slice.total)} ({(slice.percent * 100).toFixed(1)}%)
                  </title>
                </path>
              ))}
            </svg>
          </div>
          <div className="flex-1 space-y-2">
            {slices.map((slice) => (
              <div key={slice.category} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-4 h-4 rounded ${getCategoryColor(slice.category)}`}
                  />
                  <span className="text-sm">{slice.category}</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-medium">{formatCurrency(slice.total)}</span>
                  <span className="text-xs text-gray-500 ml-2">
                    ({(slice.percent * 100).toFixed(1)}%)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};