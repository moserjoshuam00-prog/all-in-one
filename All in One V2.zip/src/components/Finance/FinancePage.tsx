import { IncomeForm } from '../IncomeForm';
import { ExpenseForm } from '../ExpenseForm';
import { SummaryCard } from '../SummaryCard';
import { CategoryPieChart } from '../CategoryPieChart';
import { IncomeExpenseBar } from '../IncomeExpenseBar';
import { ExpenseList } from '../ExpenseList';
import { Expense } from '../../types';

interface FinancePageProps {
  income: number;
  expenses: Expense[];
  categories: string[];
  totalExpenses: number;
  remaining: number;
  isPositive: number;
  getCategoryTotal: (category: string) => number;
  onSetIncome: (income: number) => void;
  onAddExpense: (expense: Omit<Expense, 'id' | 'date'>) => void;
  onUpdateExpense: (id: string, expense: Omit<Expense, 'id'>) => void;
  onDeleteExpense: (id: string) => void;
  onAddCategory: (category: string) => void;
}

export const FinancePage = ({
  income,
  expenses,
  categories,
  totalExpenses,
  remaining,
  isPositive,
  getCategoryTotal,
  onSetIncome,
  onAddExpense,
  onUpdateExpense,
  onDeleteExpense,
  onAddCategory,
}: FinancePageProps) => {
  const [editingExpense, setEditingExpense] = useState<Expense | undefined>();

  const handleAddExpense = (expense: Omit<Expense, 'id' | 'date'>) => {
    if (editingExpense) {
      onUpdateExpense(editingExpense.id, expense);
      setEditingExpense(undefined);
    } else {
      onAddExpense(expense);
    }
  };

  const handleEditExpense = (expense: Expense) => {
    setEditingExpense(expense);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingExpense(undefined);
  };

  const handleDeleteExpense = (id: string) => {
    if (confirm('Möchtest du diese Ausgabe wirklich löschen?')) {
      onDeleteExpense(id);
      if (editingExpense?.id === id) {
        setEditingExpense(undefined);
      }
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
          Finanzen
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Verwalte dein Budget und Ausgaben
        </p>
      </div>

      <SummaryCard
        income={income}
        totalExpenses={totalExpenses}
        remaining={remaining}
        isPositive={isPositive}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <IncomeForm income={income} onSetIncome={onSetIncome} />
        <ExpenseForm
          categories={categories}
          onAddExpense={handleAddExpense}
          onAddCategory={onAddCategory}
          editingExpense={editingExpense}
          onCancelEdit={handleCancelEdit}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CategoryPieChart
          getCategoryTotal={getCategoryTotal}
          categories={categories}
          totalExpenses={totalExpenses}
        />
        <IncomeExpenseBar
          income={income}
          totalExpenses={totalExpenses}
          isPositive={isPositive}
        />
      </div>

      <ExpenseList
        expenses={expenses}
        onEdit={handleEditExpense}
        onDelete={handleDeleteExpense}
      />
    </div>
  );
};