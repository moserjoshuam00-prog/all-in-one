import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { BarChart3 } from 'lucide-react';

interface IncomeExpenseBarProps {
  income: number;
  totalExpenses: number;
  isPositive: boolean;
}

export const IncomeExpenseBar = ({
  income,
  totalExpenses,
  isPositive,
}: IncomeExpenseBarProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR',
    }).format(value);
  };

  const maxValue = Math.max(income, totalExpenses) || 1;
  const incomeHeight = (income / maxValue) * 100;
  const expenseHeight = (totalExpenses / maxValue) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Einnahmen vs. Ausgaben
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-end justify-center gap-8 h-64">
          <div className="flex flex-col items-center gap-2 flex-1 max-w-32">
            <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
              {formatCurrency(income)}
            </div>
            <div
              className="w-full bg-green-500 rounded-t-lg transition-all duration-500"
              style={{ height: `${incomeHeight}%` }}
            />
            <div className="text-sm font-medium">Einnahmen</div>
          </div>
          <div className="flex flex-col items-center gap-2 flex-1 max-w-32">
            <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
              {formatCurrency(totalExpenses)}
            </div>
            <div
              className="w-full bg-red-500 rounded-t-lg transition-all duration-500"
              style={{ height: `${expenseHeight}%` }}
            />
            <div className="text-sm font-medium">Ausgaben</div>
          </div>
        </div>
        <div className="text-center mt-4">
          <p
            className={`text-lg font-semibold ${
              isPositive ? 'text-green-600' : 'text-red-600'
            }`}
          >
            {isPositive ? '✓ Im Plus' : '⚠ Im Minus'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};