import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { CheckSquare2, Clock, CheckCircle2 } from 'lucide-react';

interface TasksOverviewProps {
  pendingCount: number;
  completedCount: number;
  nextTasks: Array<{ title: string; dueDate?: string; priority: string }>;
}

export const TasksOverview = ({ pendingCount, completedCount, nextTasks }: TasksOverviewProps) => {
  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) return 'Heute';
    if (date.toDateString() === tomorrow.toDateString()) return 'Morgen';
    return date.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 dark:bg-red-900/20';
      case 'medium': return 'text-amber-600 bg-amber-50 dark:bg-amber-900/20';
      case 'low': return 'text-green-600 bg-green-50 dark:bg-green-900/20';
      default: return 'text-gray-600 bg-gray-50 dark:bg-gray-900/20';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return 'Hoch';
      case 'medium': return 'Mittel';
      case 'low': return 'Niedrig';
      default: return '';
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <CheckSquare2 className="h-5 w-5 text-blue-600" />
          Aufgaben Übersicht
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">{pendingCount}</p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Offen</p>
          </div>
          <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <p className="text-2xl font-bold text-green-600">{completedCount}</p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Erledigt</p>
          </div>
        </div>
        
        {nextTasks.length > 0 && (
          <div>
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center gap-1">
              <Clock className="h-4 w-4" />
              Nächste Aufgaben
            </p>
            <div className="space-y-2">
              {nextTasks.map((task, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded-lg text-sm"
                >
                  <span className="truncate flex-1">{task.title}</span>
                  <div className="flex items-center gap-2 ml-2">
                    {task.dueDate && (
                      <span className="text-xs text-gray-500">{formatDate(task.dueDate)}</span>
                    )}
                    <span className={`text-xs px-2 py-0.5 rounded-full ${getPriorityColor(task.priority)}`}>
                      {getPriorityLabel(task.priority)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {nextTasks.length === 0 && (
          <div className="text-center py-4 text-gray-500 text-sm">
            <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-green-500" />
            Alle Aufgaben erledigt!
          </div>
        )}
      </CardContent>
    </Card>
  );
};