import { Card, CardContent } from '../ui/card';
import { CheckSquare2, Wallet, Flame, ArrowRight } from 'lucide-react';
import { Button } from '../ui/button';
import { TabType } from '../../types';

interface NavigationCardsProps {
  onNavigate: (tab: TabType) => void;
}

const cards = [
  {
    id: 'tasks' as TabType,
    title: 'Aufgaben',
    description: 'Verwalte deine To-Do Liste',
    icon: CheckSquare2,
    color: 'bg-blue-500',
    hoverColor: 'hover:bg-blue-600',
  },
  {
    id: 'finance' as TabType,
    title: 'Finanzen',
    description: 'Budget & Ausgaben tracken',
    icon: Wallet,
    color: 'bg-green-500',
    hoverColor: 'hover:bg-green-600',
  },
  {
    id: 'habits' as TabType,
    title: 'Gewohnheiten',
    description: 'Baue gute Routinen auf',
    icon: Flame,
    color: 'bg-orange-500',
    hoverColor: 'hover:bg-orange-600',
  },
];

export const NavigationCards = ({ onNavigate }: NavigationCardsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <Card
            key={card.id}
            className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
            onClick={() => onNavigate(card.id)}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg ${card.color} ${card.hoverColor} transition-colors`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>
              <h3 className="font-semibold text-lg mb-1">{card.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{card.description}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};