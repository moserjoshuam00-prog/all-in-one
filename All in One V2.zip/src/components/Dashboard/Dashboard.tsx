import { ArrowRight, TrendingUp, TrendingDown, Target, Flame, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { TabType } from '../../types';

interface DashboardProps {
  pendingTasks: number;
  completedTasks: number;
  nextTasks: any[];
  remaining: number;
  income: number;
  totalExpenses: number;
  isPositive: number;
  savingsGoal: number;
  activeHabits: number;
  maxStreak: number;
  todayProgress: number;
  onNavigate: (tab: TabType) => void;
}

export const Dashboard = ({
  pendingTasks,
  completedTasks,
  nextTasks,
  remaining,
  income,
  totalExpenses,
  isPositive,
  savingsGoal,
  activeHabits,
  maxStreak,
  todayProgress,
  onNavigate,
}: DashboardProps) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR',
    }).format(amount);
  };

  const savingsProgress = income > 0 ? (remaining / income) * 100 : 0;
  const habitProgress = activeHabits > 0 ? (todayProgress / activeHabits) * 100 : 0;

  return (
    <div className="space-y-6 pb-20">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
          Willkommen zurück! 👋
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Hier ist deine Übersicht für heute.
        </p>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-600 dark:text-blue-400">Aufgaben</span>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {pendingTasks}
            </p>
            <p className="text-xs text-gray-500">offen</p>
          </CardContent>
        </Card>

        <Card className="bg-green-50 dark:bg-green-900/20 border-green-100 dark:border-green-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              {isPositive >= 0 ? (
                <TrendingUp className="h-4 w-4 text-green-600" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-600" />
              )}
              <span className={`text-sm font-medium ${isPositive >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                Budget
              </span>
            </div>
            <p className={`text-2xl font-bold ${isPositive >= 0 ? 'text-green-700' : 'text-red-700'}`}>
              {formatCurrency(remaining)}
            </p>
            <p className="text-xs text-gray-500">übrig</p>
          </CardContent>
        </Card>

        <Card className="bg-orange-50 dark:bg-orange-900/20 border-orange-100 dark:border-orange-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-600 dark:text-orange-400">Streak</span>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {maxStreak}
            </p>
            <p className="text-xs text-gray-500">Tage</p>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 dark:bg-purple-900/20 border-purple-100 dark:border-purple-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-600 dark:text-purple-400">Sparen</span>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {savingsProgress.toFixed(0)}%
            </p>
            <p className="text-xs text-gray-500">Rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Navigation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Tasks Card */}
        <Card className="hover:shadow-lg transition-shadow cursor-pointer group" onClick={() => onNavigate('tasks')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <span className="text-lg">Aufgaben</span>
              <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-blue-600 transition-colors" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Fortschritt</span>
                <span className="font-medium">{completedTasks} / {pendingTasks + completedTasks}</span>
              </div>
              <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-600 transition-all duration-500"
                  style={{ width: `${(completedTasks / (pendingTasks + completedTasks || 1)) * 100}%` }}
                />
              </div>
              {nextTasks.length > 0 && (
                <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                  <p className="text-xs text-gray-500 mb-2">Nächste Aufgaben:</p>
                  <div className="space-y-1">
                    {nextTasks.slice(0, 2).map((task) => (
                      <div key={task.id} className="flex items-center gap-2 text-sm">
                        <div className={`w-2 h-2 rounded-full ${
                          task.priority === 'high' ? 'bg-red-500' : 
                          task.priority === 'medium' ? 'bg-amber-500' : 'bg-green-500'
                        }`} />
                        <span className="truncate text-gray-700 dark:text-gray-300">{task.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Finance Card */}
        <Card className="hover:shadow-lg transition-shadow cursor-pointer group" onClick={() => onNavigate('finance')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <span className="text-lg">Finanzen</span>
              <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-green-600 transition-colors" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500">Einnahmen</p>
                  <p className="text-lg font-semibold text-green-600">{formatCurrency(income)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Ausgaben</p>
                  <p className="text-lg font-semibold text-red-600">{formatCurrency(totalExpenses)}</p>
                </div>
              </div>
              <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-600 dark:text-gray-400">Restbudget</span>
                  <span className={`font-medium ${isPositive >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {isPositive >= 0 ? 'Im Plus' : 'Im Minus'}
                  </span>
                </div>
                <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${isPositive >= 0 ? 'bg-green-500' : 'bg-red-500'}`}
                    style={{ width: `${Math.min(Math.abs(savingsProgress), 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Habits Card */}
        <Card className="hover:shadow-lg transition-shadow cursor-pointer group" onClick={() => onNavigate('habits')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <span className="text-lg">Gewohnheiten</span>
              <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-orange-600 transition-colors" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Heute erledigt</span>
                <span className="font-medium">{todayProgress} / {activeHabits}</span>
              </div>
              <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-orange-500 transition-all duration-500"
                  style={{ width: `${habitProgress}%` }}
                />
              </div>
              {activeHabits > 0 ? (
                <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                  <p className="text-xs text-gray-500 mb-2">Aktive Gewohnheiten:</p>
                  <div className="flex flex-wrap gap-2">
                    {Array.from({ length: Math.min(activeHabits, 3) }).map((_, i) => (
                      <div key={i} className="w-8 h-8 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                        <Flame className="h-4 w-4 text-orange-600" />
                      </div>
                    ))}
                    {activeHabits > 3 && (
                      <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-xs text-gray-500">
                        +{activeHabits - 3}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <p className="text-sm text-gray-500 text-center py-2">Noch keine Gewohnheiten</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};