import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Flame, Target, CalendarCheck } from 'lucide-react';

interface HabitOverviewProps {
  activeHabits: number;
  maxStreak: number;
  todayProgress: number;
}

export const HabitOverview = ({
  activeHabits,
  maxStreak,
  todayProgress,
}: HabitOverviewProps) => {
  const todayProgressPercent = activeHabits > 0 ? (todayProgress / activeHabits) * 100 : 0;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Flame className="h-5 w-5 text-orange-600" />
          Habit Tracker
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="text-center p-2 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
            <p className="text-xl font-bold text-orange-600">{activeHabits}</p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Aktiv</p>
          </div>
          <div className="text-center p-2 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <p className="text-xl font-bold text-red-600">{maxStreak}</p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Best. Streak</p>
          </div>
          <div className="text-center p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <p className="text-xl font-bold text-green-600">{todayProgress}</p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Heute</p>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1">
                <CalendarCheck className="h-4 w-4" />
                Heutiger Fortschritt
              </span>
              <span className="text-sm font-medium">{todayProgress}/{activeHabits}</span>
            </div>
            <div className="relative h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div
                className="absolute left-0 top-0 h-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-500"
                style={{ width: `${todayProgressPercent}%` }}
              />
            </div>
          </div>

          {maxStreak > 0 && (
            <div className="flex items-center gap-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <Target className="h-4 w-4 text-yellow-600" />
              <span className="text-sm text-gray-700 dark:text-gray-300">
                Längste Serie: <span className="font-bold text-yellow-600">{maxStreak} Tage</span>
              </span>
            </div>
          )}

          {activeHabits === 0 && (
            <div className="text-center py-4 text-gray-500 text-sm">
              <Flame className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              Noch keine Gewohnheiten erstellt
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};