import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Wallet, TrendingUp, TrendingDown, PiggyBank } from 'lucide-react';
import { SavingsGoal } from '../../types';

interface FinanceOverviewProps {
  remaining: number;
  income: number;
  totalExpenses: number;
  isPositive: boolean;
  savingsGoal: SavingsGoal | null;
}

export const FinanceOverview = ({
  remaining,
  income,
  totalExpenses,
  isPositive,
  savingsGoal,
}: FinanceOverviewProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const savingsProgress = savingsGoal
    ? (savingsGoal.currentAmount / savingsGoal.targetAmount) * 100
    : 0;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Wallet className="h-5 w-5 text-green-600" />
          Finanz Übersicht
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <span className="text-sm text-gray-600 dark:text-gray-400">Restbudget</span>
            <span className={`text-lg font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(remaining)}
            </span>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center gap-1 text-green-600 mb-1">
                <TrendingUp className="h-4 w-4" />
                <span className="text-xs">Einnahmen</span>
              </div>
              <p className="text-lg font-bold">{formatCurrency(income)}</p>
            </div>
            <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <div className="flex items-center gap-1 text-red-600 mb-1">
                <TrendingDown className="h-4 w-4" />
                <span className="text-xs">Ausgaben</span>
              </div>
              <p className="text-lg font-bold">{formatCurrency(totalExpenses)}</p>
            </div>
          </div>

          <div className={`p-3 rounded-lg ${isPositive ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'}`}>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Status</span>
              <span className={`text-sm font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                {isPositive ? '✓ Im Plus' : '⚠ Im Minus'}
              </span>
            </div>
          </div>

          {savingsGoal && (
            <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <PiggyBank className="h-4 w-4" />
                <span className="text-sm font-medium">Sparziel: {savingsGoal.name}</span>
              </div>
              <div className="relative h-2 bg-purple-200 dark:bg-purple-800 rounded-full overflow-hidden">
                <div
                  className="absolute left-0 top-0 h-full bg-purple-600 transition-all duration-500"
                  style={{ width: `${Math.min(savingsProgress, 100)}%` }}
                />
              </div>
              <div className="flex justify-between mt-1 text-xs text-gray-600 dark:text-gray-400">
                <span>{formatCurrency(savingsGoal.currentAmount)}</span>
                <span>{formatCurrency(savingsGoal.targetAmount)}</span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};