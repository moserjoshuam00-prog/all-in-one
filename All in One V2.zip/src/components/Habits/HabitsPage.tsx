import { useState } from 'react';
import { Flame } from 'lucide-react';
import { HabitForm } from './HabitForm';
import { HabitList } from './HabitList';
import { Habit } from '../../types';

interface HabitsPageProps {
  habits: Habit[];
  onAddHabit: (habit: Omit<Habit, 'id' | 'createdAt' | 'completedDates'>) => void;
  onDeleteHabit: (id: string) => void;
  onToggleHabitDay: (id: string, date: string) => void;
  getStreak: (habit: Habit) => number;
}

export const HabitsPage = ({
  habits,
  onAddHabit,
  onDeleteHabit,
  onToggleHabitDay,
  getStreak,
}: HabitsPageProps) => {
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
            <Flame className="h-6 w-6 text-orange-600" />
            Habit Tracker
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            {habits.length} aktive Gewohnheiten
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition-colors"
        >
          {showForm ? 'Abbrechen' : '+ Neue Gewohnheit'}
        </button>
      </div>

      {showForm && <HabitForm onAddHabit={onAddHabit} />}

      <HabitList
        habits={habits}
        onToggleDay={onToggleHabitDay}
        onDelete={onDeleteHabit}
        getStreak={getStreak}
      />
    </div>
  );
};