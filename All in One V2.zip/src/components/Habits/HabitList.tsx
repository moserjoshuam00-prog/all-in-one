import { Trash2, Edit } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Habit } from '../../types';

interface HabitListProps {
  habits: Habit[];
  onToggleDay: (id: string, date: string) => void;
  onDelete: (id: string) => void;
  getStreak: (habit: Habit) => number;
}

export const HabitList = ({ habits, onToggleDay, onDelete, getStreak }: HabitListProps) => {
  const getTodayString = () => new Date().toISOString().split('T')[0];
  const today = getTodayString();

  const getLast7Days = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push({
        date: d.toISOString().split('T')[0],
        dayName: d.toLocaleDateString('de-DE', { weekday: 'short' }),
      });
    }
    return days;
  };

  const last7Days = getLast7Days();

  if (habits.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          <p>Noch keine Gewohnheiten erstellt</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {habits.map((habit) => (
        <Card key={habit.id} className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${habit.color} flex items-center justify-center text-white font-bold text-lg`}>
                  {habit.icon}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">{habit.name}</h3>
                  {habit.description && (
                    <p className="text-sm text-gray-500">{habit.description}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-right mr-2">
                  <p className="text-xs text-gray-500">Aktuelle Serie</p>
                  <p className="text-lg font-bold text-orange-600">{getStreak(habit)}</p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (confirm('Gewohnheit löschen?')) onDelete(habit.id);
                  }}
                  className="h-8 w-8 text-gray-400 hover:text-red-600"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex justify-between gap-1">
              {last7Days.map((day) => {
                const isCompleted = habit.completedDates.includes(day.date);
                const isToday = day.date === today;
                return (
                  <button
                    key={day.date}
                    onClick={() => onToggleDay(habit.id, day.date)}
                    className={`flex-1 py-2 rounded-lg text-center transition-all ${
                      isCompleted
                        ? `${habit.color} text-white`
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                    } ${isToday ? 'ring-2 ring-offset-1 ring-blue-500' : ''}`}
                    title={day.date}
                  >
                    <div className="text-xs font-medium">{day.dayName}</div>
                    <div className="text-lg mt-1">
                      {isCompleted ? '✓' : ''}
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};