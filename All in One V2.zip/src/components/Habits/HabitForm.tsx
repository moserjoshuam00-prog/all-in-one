import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Habit } from '../../types';

const HABIT_COLORS = [
  { name: 'Rot', value: 'bg-red-500' },
  { name: 'Orange', value: 'bg-orange-500' },
  { name: 'Amber', value: 'bg-amber-500' },
  { name: 'Grün', value: 'bg-green-500' },
  { Name: 'Teal', value: 'bg-teal-500' },
  { name: 'Blau', value: 'bg-blue-500' },
  { name: 'Indigo', value: 'bg-indigo-500' },
  { name: 'Lila', value: 'bg-purple-500' },
  { name: 'Pink', value: 'bg-pink-500' },
];

interface HabitFormProps {
  onAddHabit: (habit: Omit<Habit, 'id' | 'createdAt' | 'completedDates'>) => void;
}

export const HabitForm = ({ onAddHabit }: HabitFormProps) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState('bg-blue-500');
  const [icon, setIcon] = useState('✓');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onAddHabit({
      name: name.trim(),
      description: description.trim(),
      icon,
      color,
      targetDays: [0, 1, 2, 3, 4, 5, 6], // Default: Every day
    });

    setName('');
    setDescription('');
    setColor('bg-blue-500');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Plus className="h-5 w-5" />
          Neue Gewohnheit
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="habit-name">Name *</Label>
            <Input
              id="habit-name"
              placeholder="z.B. Sport treiben"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="habit-desc">Beschreibung</Label>
            <Input
              id="habit-desc"
              placeholder="z.B. 30 Minuten Joggen"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div>
            <Label>Farbe</Label>
            <div className="flex gap-2 mt-2 flex-wrap">
              {HABIT_COLORS.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setColor(c.value)}
                  className={`w-8 h-8 rounded-full ${c.value} ${color === c.value ? 'ring-2 ring-offset-2 ring-gray-400' : 'opacity-60'}`}
                  title={c.name}
                />
              ))}
            </div>
          </div>
          <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700">
            Gewohnheit erstellen
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};