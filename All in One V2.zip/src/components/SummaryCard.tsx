import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ArrowUp, ArrowDown, Wallet } from 'lucide-react';

interface SummaryCardProps {
  income: number;
  totalExpenses: number;
  remaining: number;
  isPositive: boolean;
}

export const SummaryCard = ({
  income,
  totalExpenses,
  remaining,
  isPositive,
}: SummaryCardProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR',
    }).format(value);
  };

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-900 border-blue-200 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wallet className="h-5 w-5 text-blue-600" />
          Gesamtübersicht
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Einnahmen</p>
            <p className="text-2xl font-bold text-green-600 flex items-center justify-center gap-1">
              <ArrowUp className="h-5 w-5" />
              {formatCurrency(income)}
            </p>
          </div>
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Ausgaben</p>
            <p className="text-2xl font-bold text-red-600 flex items-center justify-center gap-1">
              <ArrowDown className="h-5 w-5" />
              {formatCurrency(totalExpenses)}
            </p>
          </div>
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Verbleibend</p>
            <p
              className={`text-2xl font-bold flex items-center justify-center gap-1 ${
                isPositive ? 'text-green-600' : 'text-red-600'
              }`}
            >
              {isPositive ? <ArrowUp className="h-5 w-5" /> : <ArrowDown className="h-5 w-5" />}
              {formatCurrency(remaining)}
            </p>
            <p className="text-xs mt-1 text-gray-500">
              {isPositive ? 'Im Plus' : 'Im Minus'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};