import { useState } from 'react';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

interface IncomeFormProps {
  income: number;
  onSetIncome: (income: number) => void;
}

export const IncomeForm = ({ income, onSetIncome }: IncomeFormProps) => {
  const [value, setValue] = useState(income.toString());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(value);
    if (!isNaN(parsed) && parsed >= 0) {
      onSetIncome(parsed);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Monatliches Einkommen</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex gap-3">
          <div className="flex-1">
            <Label htmlFor="income" className="sr-only">
              Einkommen
            </Label>
            <Input
              id="income"
              type="number"
              placeholder="0.00"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              step="0.01"
              min="0"
              className="text-lg"
            />
          </div>
          <Button type="submit" className="bg-green-600 hover:bg-green-700">
            Speichern
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};