import { useState } from 'react';
import { Plus, Filter } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { TaskForm } from './TaskForm';
import { TaskList } from './TaskList';
import { Task } from '../../types';

interface TasksPageProps {
  tasks: Task[];
  pendingTasks: Task[];
  completedTasks: Task[];
  onAddTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  onUpdateTask: (id: string, updates: Partial<Task>) => void;
  onDeleteTask: (id: string) => void;
  onToggleTask: (id: string) => void;
}

export const TasksPage = ({
  tasks,
  pendingTasks,
  completedTasks,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onToggleTask,
}: TasksPageProps) => {
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [editingTask, setEditingTask] = useState<Task | undefined>();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTasks = tasks
    .filter((task) => {
      if (filter === 'pending') return !task.completed;
      if (filter === 'completed') return task.completed;
      return true;
    })
    .filter((task) =>
      task.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const handleAddTask = (task: Omit<Task, 'id' | 'createdAt'>) => {
    onAddTask(task);
    setShowForm(false);
    setEditingTask(undefined);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setShowForm(true);
  };

  const handleUpdateTask = (id: string, updates: Partial<Task>) => {
    onUpdateTask(id, updates);
    setEditingTask(undefined);
    setShowForm(false);
  };

  const handleDeleteTask = (id: string) => {
    if (confirm('Möchtest du diese Aufgabe wirklich löschen?')) {
      onDeleteTask(id);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Aufgaben
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            {pendingTasks.length} offen • {completedTasks.length} erledigt
          </p>
        </div>
        <Button onClick={() => { setShowForm(!showForm); setEditingTask(undefined); }} className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
          <Plus className="h-4 w-4 mr-2" />
          Neue Aufgabe
        </Button>
      </div>

      {showForm && (
        <Card className="border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="text-lg">
              {editingTask ? 'Aufgabe bearbeiten' : 'Neue Aufgabe erstellen'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TaskForm
              onSubmit={editingTask ? (t) => handleUpdateTask(editingTask.id, t) : handleAddTask}
              onCancel={() => { setShowForm(false); setEditingTask(undefined); }}
              initialTask={editingTask}
            />
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Aufgaben suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filter === 'all' ? 'default' : 'outline'}
                onClick={() => setFilter('all')}
                size="sm"
              >
                Alle
              </Button>
              <Button
                variant={filter === 'pending' ? 'default' : 'outline'}
                onClick={() => setFilter('pending')}
                size="sm"
              >
                Offen
              </Button>
              <Button
                variant={filter === 'completed' ? 'default' : 'outline'}
                onClick={() => setFilter('completed')}
                size="sm"
              >
                Erledigt
              </Button>
            </div>
          </div>

          <TaskList
            tasks={filteredTasks}
            onToggle={onToggleTask}
            onEdit={handleEditTask}
            onDelete={handleDeleteTask}
          />
        </CardContent>
      </Card>
    </div>
  );
};