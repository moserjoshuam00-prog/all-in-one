export interface Expense {
  id: string;
  name: string;
  amount: number;
  category: string;
  date: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  completed: boolean;
  createdAt: string;
}

export interface Habit {
  id: string;
  name: string;
  description?: string;
  icon: string;
  color: string;
  targetDays: number[]; // 0-6 (Sonntag-Samstag)
  completedDates: string[]; // ISO Date strings
  createdAt: string;
}

export type TabType = 'dashboard' | 'tasks' | 'finance' | 'habits';