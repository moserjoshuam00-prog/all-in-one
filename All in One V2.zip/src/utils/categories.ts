export const DEFAULT_CATEGORIES = [
  'Wohnen',
  'Essen',
  'Transport',
  'Freizeit',
  'Gesundheit',
  'Shopping',
  'Bildung',
  'Sonstiges',
] as const;

export const CATEGORY_COLORS: Record<string, string> = {
  Wohnen: 'bg-indigo-500',
  Essen: 'bg-purple-500',
  Transport: 'bg-pink-500',
  Freizeit: 'bg-amber-500',
  Gesundheit: 'bg-teal-500',
  Shopping: 'bg-rose-500',
  Bildung: 'bg-cyan-500',
  Sonstiges: 'bg-gray-500',
};

export const getCategoryColor = (category: string): string => {
  return CATEGORY_COLORS[category] || 'bg-gray-500';
};