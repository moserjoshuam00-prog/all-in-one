import { useState, useEffect } from 'react';
import { BudgetHeader } from './components/BudgetHeader';
import { Dashboard } from './components/Dashboard/Dashboard';
import { TasksPage } from './components/Tasks/TasksPage';
import { FinancePage } from './components/Finance/FinancePage';
import { HabitsPage } from './components/Habits/HabitsPage';
import { TabBar } from './components/Navigation/TabBar';
import { useBudget } from './hooks/useBudget';
import { useTasks } from './hooks/useTasks';
import { useHabits } from './hooks/useHabits';
import { TabType } from './types';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  const {
    state: budgetState,
    totalExpenses,
    remaining,
    isPositive,
    getCategoryTotal,
    addExpense,
    updateExpense,
    deleteExpense,
    addCategory,
    setIncome,
    toggleDarkMode,
  } = useBudget();

  const {
    tasks,
    pendingTasks,
    completedTasks,
    nextTasks,
    addTask,
    updateTask,
    deleteTask,
    toggleTask,
  } = useTasks();

  const {
    habits,
    activeHabits,
    maxStreak,
    todayProgress,
    getStreak,
    addHabit,
    deleteHabit,
    toggleHabitDay,
  } = useHabits();

  useEffect(() => {
    if (budgetState.isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [budgetState.isDarkMode]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <BudgetHeader
          isDarkMode={budgetState.isDarkMode}
          onToggleDarkMode={toggleDarkMode}
        />

        <main className="mt-8">
          {activeTab === 'dashboard' && (
            <Dashboard
              pendingTasks={pendingTasks.length}
              completedTasks={completedTasks.length}
              nextTasks={nextTasks}
              remaining={remaining}
              income={budgetState.income}
              totalExpenses={totalExpenses}
              isPositive={isPositive}
              savingsGoal={budgetState.savingsGoal}
              activeHabits={activeHabits}
              maxStreak={maxStreak}
              todayProgress={todayProgress}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'tasks' && (
            <TasksPage
              tasks={tasks}
              pendingTasks={pendingTasks}
              completedTasks={completedTasks}
              onAddTask={addTask}
              onUpdateTask={updateTask}
              onDeleteTask={deleteTask}
              onToggleTask={toggleTask}
            />
          )}

          {activeTab === 'finance' && (
            <FinancePage
              income={budgetState.income}
              expenses={budgetState.expenses}
              categories={budgetState.categories}
              totalExpenses={totalExpenses}
              remaining={remaining}
              isPositive={isPositive}
              getCategoryTotal={getCategoryTotal}
              onSetIncome={setIncome}
              onAddExpense={addExpense}
              onUpdateExpense={updateExpense}
              onDeleteExpense={deleteExpense}
              onAddCategory={addCategory}
            />
          )}

          {activeTab === 'habits' && (
            <HabitsPage
              habits={habits}
              onAddHabit={addHabit}
              onDeleteHabit={deleteHabit}
              onToggleHabitDay={toggleHabitDay}
              getStreak={getStreak}
            />
          )}
        </main>
      </div>

      <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

export default App;